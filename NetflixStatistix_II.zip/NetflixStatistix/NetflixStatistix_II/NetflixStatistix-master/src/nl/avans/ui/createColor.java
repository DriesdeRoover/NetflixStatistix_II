package nl.avans.ui;

import java.awt.*;

public class createColor {

    public Color createRed(){
        Color netflixRed = new Color(229, 9, 20);
        return netflixRed;
    }
}
